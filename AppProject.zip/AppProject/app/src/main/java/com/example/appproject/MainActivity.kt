package com.example.appproject

import android.Manifest
import android.content.pm.PackageManager
import android.database.Cursor
import android.os.Bundle
import android.telephony.SmsManager
import android.widget.Button
import android.widget.EditText
import android.widget.GridView
import android.widget.SimpleCursorAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var dbHelper: DatabaseHelper
    private val SMS_PERMISSION_CODE = 101

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        dbHelper = DatabaseHelper(this)

        // UI Element References
        val etUsername = findViewById<EditText>(R.id.etUsername)
        val etPassword = findViewById<EditText>(R.id.etPassword)
        val btnLogin = findViewById<Button>(R.id.btnLogin)
        val btnRegister = findViewById<Button>(R.id.btnRegister)

        val etItemId = findViewById<EditText>(R.id.etItemId)
        val etItemName = findViewById<EditText>(R.id.etItemName)
        val etItemDetails = findViewById<EditText>(R.id.etItemDetails)
        val btnAdd = findViewById<Button>(R.id.btnAdd)
        val btnUpdate = findViewById<Button>(R.id.btnUpdate)
        val btnDelete = findViewById<Button>(R.id.btnDelete)
        val gridViewItems = findViewById<GridView>(R.id.gridViewItems)

        // Load grid view data on startup
        refreshGrid(gridViewItems)

        // Register Button Logic
        btnRegister.setOnClickListener {
            val user = etUsername.text.toString().trim()
            val pass = etPassword.text.toString().trim()
            if (user.isNotEmpty() && pass.isNotEmpty()) {
                val success = dbHelper.registerUser(user, pass)
                if (success) {
                    Toast.makeText(this, "User registered successfully!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Registration failed. User may already exist.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter username and password.", Toast.LENGTH_SHORT).show()
            }
        }

        // Login Button Logic
        btnLogin.setOnClickListener {
            val user = etUsername.text.toString().trim()
            val pass = etPassword.text.toString().trim()
            if (user.isNotEmpty() && pass.isNotEmpty()) {
                val isValid = dbHelper.checkUser(user, pass)
                if (isValid) {
                    Toast.makeText(this, "Login successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Invalid credentials.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Please enter username and password.", Toast.LENGTH_SHORT).show()
            }
        }

        // Add Item Logic (with SMS notification trigger option)
        btnAdd.setOnClickListener {
            val name = etItemName.text.toString().trim()
            val details = etItemDetails.text.toString().trim()
            if (name.isNotEmpty() && details.isNotEmpty()) {
                val success = dbHelper.addItem(name, details)
                if (success) {
                    Toast.makeText(this, "Item added!", Toast.LENGTH_SHORT).show()
                    refreshGrid(gridViewItems)
                    checkAndSendSms("Alert: New item '$name' added to database.")
                } else {
                    Toast.makeText(this, "Error adding item.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Fill out item name and details.", Toast.LENGTH_SHORT).show()
            }
        }

        // Update Item Logic
        btnUpdate.setOnClickListener {
            val id = etItemId.text.toString().trim()
            val name = etItemName.text.toString().trim()
            val details = etItemDetails.text.toString().trim()
            if (id.isNotEmpty() && name.isNotEmpty() && details.isNotEmpty()) {
                val success = dbHelper.updateItem(id, name, details)
                if (success) {
                    Toast.makeText(this, "Item updated!", Toast.LENGTH_SHORT).show()
                    refreshGrid(gridViewItems)
                } else {
                    Toast.makeText(this, "Update failed. Check ID.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter ID, Name, and Details to update.", Toast.LENGTH_SHORT).show()
            }
        }

        // Delete Item Logic
        btnDelete.setOnClickListener {
            val id = etItemId.text.toString().trim()
            if (id.isNotEmpty()) {
                val success = dbHelper.deleteItem(id)
                if (success) {
                    Toast.makeText(this, "Item deleted!", Toast.LENGTH_SHORT).show()
                    refreshGrid(gridViewItems)
                } else {
                    Toast.makeText(this, "Delete failed. Check ID.", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(this, "Enter Item ID to delete.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Refresh GridView helper
    private fun refreshGrid(gridView: GridView) {
        val cursor: Cursor = dbHelper.getAllItems()
        val fromColumns = arrayOf(DatabaseHelper.COL_ITEM_NAME, DatabaseHelper.COL_ITEM_DETAILS)
        val toViews = intArrayOf(android.R.id.text1, android.R.id.text2)

        // Using a simple built-in layout to display two lines of text in the grid cells
        val adapter = SimpleCursorAdapter(this, android.R.layout.simple_list_item_2, cursor, fromColumns, toViews, 0)
        gridView.adapter = adapter
    }

    // SMS Permission Check and Notification
    private fun checkAndSendSms(message: String) {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED) {
            sendSmsAlert("5551212", message) // Default emulator test number
        } else {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.SEND_SMS), SMS_PERMISSION_CODE)
        }
    }

    private fun sendSmsAlert(phoneNumber: String, message: String) {
        try {
            val smsManager = SmsManager.getDefault()
            smsManager.sendTextMessage(phoneNumber, null, message, null, null)
            Toast.makeText(this, "SMS Notification sent.", Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            Toast.makeText(this, "SMS failed to send.", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == SMS_PERMISSION_CODE) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "SMS Permission Granted.", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "SMS Permission Denied. App functions normally without it.", Toast.LENGTH_LONG).show()
            }
        }
    }
}